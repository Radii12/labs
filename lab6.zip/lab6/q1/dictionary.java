import java.util.HashMap;
import java.util.ArrayList;
import java.util.Collections;
public class dictionary{

    public static void getAll(String list, HashMap<String, ArrayList> Dic){
     System.out.println("key " + list +  " " + Dic.get(list));

    }
    public static void main(String[] args) {
        ArrayList<String> A = new ArrayList<String>();
        A.add("apple");
        A.add("answer");
        A.add("avocado");
        Collections.sort(A);
        ArrayList<String> B = new ArrayList<String>();
        B.add("ball");
        B.add("banana");
        Collections.sort(B);

        ArrayList<String> C = new ArrayList<String>();
        C.add("center");
        C.add("country");
        C.add("count");
        Collections.sort(C);

        HashMap<String, ArrayList> Dic = new HashMap<String, ArrayList>();
        Dic.put("a", A);
        Dic.put("b", B);
        Dic.put("c", C);

        for (String i : Dic.keySet()) {
            System.out.println("key: " + i + " value: " + Dic.get(i));
        }

        dictionary.getAll("b",Dic);
        dictionary.getAll("a",Dic);
        dictionary.getAll("c",Dic);

    }
}