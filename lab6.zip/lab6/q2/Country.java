public class Country {
    private String code;
    private String name;
    private int area;
    private String Continent;
    
    private int population;
    
    private int capital;

    

    public Country(String code,String name,String contient,int surface,int population, int capital){
        this.code = code;
        this.name = name;
        this.Continent = contient;
        this.area = surface;
        this.population = population;
        
        this.capital = capital;

    }

    public int getCapital(){
        return this.capital;

    }
   
    public int getPopulation(){
        return this.population;

    }
    public int getArea(){
        return this.area;

    }
    public String getContinent(){
        return this.Continent;

    }
    public String getName(){
        return this.name;

    }
    public String getCode(){
        return this.code;

    }



}
