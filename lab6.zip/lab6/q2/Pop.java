
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Optional;

public class Pop {
  public static void main(String[] args) {
    List<Country> countries = new ArrayList<Country>();
    countries.add(new Country("EGY", "Egypt", "africa", 01545, 80880, 5555));
    countries.add(new Country("FRS", "France", "Eroupe", 2555, 0111, 3000));
    countries.add(new Country("RSY", "russia", "asia", 25562, 50084, 6552));
    countries.add(new Country("SSS", "syria", "asia", 555400, 12000, 12222));
    Optional<Integer> maxPop = countries.stream().map(P -> P.getPopulation()).max(Comparator.naturalOrder());
    Optional<Integer> minPop = countries.stream().map(P -> P.getPopulation()).max(Comparator.reverseOrder());
    System.out.println("Max " + maxPop.get());

    System.out.println("min " + minPop.get());

    for (Country country : countries) {
      Optional<Integer> maxPopCountry = countries.stream().filter(P -> P.getContinent() == country.getContinent())
          .map(P -> P.getPopulation()).max(Comparator.naturalOrder());

      System.out.println("max " + country.getContinent() + " " + maxPopCountry.get());
    }

  }

}

